INSERT INTO sequence VALUES (-1, 1, 1);
INSERT INTO sequence VALUES (-1, 2, 1);
INSERT INTO sequence VALUES (-1, 3, 1);
INSERT INTO sequence VALUES (-1, 4, 1);
INSERT INTO sequence VALUES (-1, 30, 1);
INSERT INTO sequence VALUES (-1, 31, 1);
