INSERT INTO sequence VALUES(${tenantid}, 10, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 11, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 20, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 21, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 22, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 23, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 24, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 25, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 26, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 27, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 30, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 31, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 70, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 71, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 72, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 90, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 9990, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 9992, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10000, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10001, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10010, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10011, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10012, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10014, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10015, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10016, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10017, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10018, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10020, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10021, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10030, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10031, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10040, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 20051, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10050, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10060, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10070, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10080, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10090, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10096, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10120, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10121, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10200, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10201, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10202, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10210, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10220, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10300, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10310, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10400, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10500, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 10501, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 20010, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 20011, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 20013, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 20040, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 20050, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 20210, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 20220, 1)
GO
INSERT INTO sequence VALUES(${tenantid}, 20096, 1)
GO
